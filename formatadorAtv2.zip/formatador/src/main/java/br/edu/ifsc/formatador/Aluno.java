package br.edu.ifsc.formatador;

public class Aluno {
	String nome;
	String telefone;
	String materia;
	String nota;
}
