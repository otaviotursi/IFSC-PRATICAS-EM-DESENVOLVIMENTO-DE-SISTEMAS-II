package br.edu.ifsc.formatador;

public class QntCarecterColuna {
	int nome = 0;
	int materia = 0;
	int telefone = 0;
	int nota = 0;
}
